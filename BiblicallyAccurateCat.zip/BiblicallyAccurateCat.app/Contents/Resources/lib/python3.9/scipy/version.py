# THIS FILE IS GENERATED DURING THE SCIPY BUILD
# See tools/version_utils.py for details

short_version = '1.10.0'
version = '1.10.0'
full_version = '1.10.0'
git_revision = 'dde5059'
commit_count = '2356'
release = True

if not release:
    version = full_version
